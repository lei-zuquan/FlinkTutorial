# 			深入浅出Flink-第三天



## :one: 一 、课前准备

掌握上节课内容



## :two: 二 、课堂主题

Flink是一个有状态的流，本次课深入了解这个有状态的流

## :three: 三 、课程目标

1. 掌握State知识
2. 掌握Flink三种State Backend
3. 掌握Flink checkpoint和savepoint原理
4. 了解Filnk的重启策略

## :four: 四 、知识要点



### :book: 1. Flink的State

#### 1.1 state概述

**Apache Flink® — Stateful Computations over Data Streams**

~~~
	Flink 是一个默认就有状态的分析引擎，前面的WordCount 案例可以做到单词的数量的累加，其实是因为在内存中保证了每个单词的出现的次数，这些数据其实就是状态数据。但是如果一个 Task 在处理过程中挂掉了，那么它在内存中的状态都会丢失，所有的数据都需要重新计算。从容错和消息处理的语义（At -least-once 和 Exactly-once）上来说，Flink引入了State 和 CheckPoint。
	State一般指一个具体的 Task/Operator 的状态，State数据默认保存在 Java 的堆内存中
~~~



* 回顾单词计数的例子

  ~~~scala
  package com.kaikeba.demo1
  
  import org.apache.flink.api.java.tuple.Tuple
  import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment, WindowedStream}
  import org.apache.flink.streaming.api.windowing.time.Time
  import org.apache.flink.streaming.api.windowing.windows.TimeWindow
  
  /**
    * 使用滑动窗口
    * 每隔1秒钟统计最近2秒钟的每个单词出现的次数
    */
  object FlinkStream {
  
    def main(args: Array[String]): Unit = {
        //构建流处理的环境
        val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
  
    //从socket获取数据
  val sourceStream: DataStream[String] = env.socketTextStream("node01",9999)
   //导入隐式转换的包
    import org.apache.flink.api.scala._
   
   //对数据进行处理
    val result: DataStream[(String, Int)] = sourceStream
                                  .flatMap(x => x.split(" ")) //按照空格切分
                                  .map(x => (x, 1))  //每个单词计为1
                                  .keyBy(0)         //按照下标为0的单词进行分组
                                  .sum(1)          //按照下标为1累加相同单词出现的1
  
  
      //对数据进行打印
      result.print()
  
      //开启任务
       env.execute("FlinkStream")
    }
  
  }
  
  ~~~

* node01执行 nc  -lk  9999  输入

  ~~~
  hadoop hadoop
  hadoop
  hive hadoop 
  ~~~

* 输出

  ~~~
  8> (hadoop,1)
  1> (hive,1)
  8> (hadoop,2)
  8> (hadoop,3)
  8> (hadoop,4)
  ~~~

![1587390209212](assets/state.png)



#### 1.2 state类型

* Flink中有两种基本类型的State, Keyed State和Operator State，他们两种都可以以两种形式存在：
  * 原生状态(raw state)
    * 由算子自己管理数据结构，当触发Checkpoint操作过程中，Flink并不知道状态数据内部的数据结构，只是将数据转换成bytes数据存储在Checkpoints中，当从Checkpoints恢复任务时，算子自己再反序列化出状态的数据结构。
  * 托管状态(managed state)
    * 由**Flink Runtime**控制和管理状态数据，并将状态数据转换成为内存的Hash tables或 RocksDB的对象存储，然后将这些数据通过内部的接口持久化到checkpoints中，任务异常时可以通过这些状态数据恢复任务。
    * 推荐使用ManagedState管理状态数据，ManagedState更好的支持状态数据的重平衡以及更加完善的内存管理

|              | Managed State                                    | Raw State        |
| ------------ | ------------------------------------------------ | ---------------- |
| 状态管理方式 | Flink Runtime托管，自动存储、自动恢复、自动伸缩  | 用户自己管理     |
| 状态数据结构 | Flink提供的常用数据结构，如ListState、MapState等 | 字节数组：byte[] |
| 使用场景     | 绝大多数Flink算子                                | 用户自定义算子   |

![Flink的状态管理](Flink%E5%BD%93%E4%B8%AD%E7%9A%84%E7%8A%B6%E6%80%81%E7%BC%96%E7%A8%8B.assets/Flink%E7%9A%84%E7%8A%B6%E6%80%81%E7%AE%A1%E7%90%86-1589418427675.png)



##### 1.2.1  Operator State(算子状态)

* operator state是task级别的state，说白了就是每个task对应一个state
* Kafka Connector source中的每个分区（task）都需要记录消费的topic的partition和offset等信息。
* operator state 只有一种托管状态：ValueState 



![1587391007087](assets/Operator State.png)

##### 1.2.2 keyed State(键控状态)

~~~
Keyed State：
	顾名思义就是基于KeyedStream上的状态，这个状态是跟特定的Key 绑定的。KeyedStream流上的每一个Key，都对应一个State。Flink针对 Keyed State 提供了以下可以保存State的数据结构.
~~~

* Keyed state托管状态有六种类型：

  * 1、==ValueState==

    ~~~
    	保存一个可以更新和检索的值（如上所述，每个值都对应到当前的输入数据的key，因此算子接收到的每个key都可能对应一个值）。 这个值可以通过update(T) 进行更新，通过 T value() 进行检索
    ~~~

  * 2、==ListState==

    ~~~
    	保存一个元素的列表。可以往这个列表中追加数据，并在当前的列表上进行检索。可以通过 add(T) 或者 addAll(List<T>) 进行添加元素，通过 Iterable<T> get() 获得整个列表。还可以通过 update(List<T>) 覆盖当前的列表	。
    ~~~

  * 3、==MapState==

    ~~~
    	维护了一个映射列表。 你可以添加键值对到状态中，也可以获得 反映当前所有映射的迭代器。使用 put(UK，UV) 或者 putAll(Map<UK，UV>) 添加映射。 使用 get(UK) 检索特定 key。 使用 entries()，keys() 和 values() 分别检索映射、 键和值的可迭代视图。
    ~~~

  * 4、ReducingState

    ~~~
    	保存一个单值，表示添加到状态的所有值的聚合。接口与ListState类似，但使用add(T) 增加元素，会使用提供的 ReduceFunction 进行聚合。
    ~~~

  * 5、AggregatingState

    ~~~
    	AggregatingState<IN, OUT>: 保留一个单值，表示添加到状态的所有值的聚合。和 ReducingState 相反的是, 聚合类型可能与添加到状态的元素的类型不同。 接口与 ListState类似，但使用 add(IN) 添加的元素会用指定的 AggregateFunction 进行聚合
    ~~~

  * 6、FoldingState

    ~~~
    	保留一个单值，表示添加到状态的所有值的聚合。 与ReducingState 相反，聚合类型可能与添加到状态的元素类型不同。接口与 ListState 类似，但使用 add（T）添加的元素会用指定的 FoldFunction 折叠成聚合值。在Flink1.4中弃用，未来版本将被完全删除。
    ~~~


![1587393629878](assets/keyed State.png)



#### 1.3 Keyed State案例演示

##### 1.3.1 ValueState

* 作用

  * 保存一个可以更新和检索的值

* 需求

  * 使用valueState实现平均值求取

* 代码开发

  ~~~scala
  package com.kaikeba.keystate
  
  import org.apache.flink.api.common.functions.RichFlatMapFunction
  import org.apache.flink.api.common.state.{ValueState, ValueStateDescriptor}
  import org.apache.flink.configuration.Configuration
  import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
  import org.apache.flink.util.Collector
  
  /**
    * 使用valueState实现平均值求取
    */
  object ValueStateOperate {
    def main(args: Array[String]): Unit = {
      val env = StreamExecutionEnvironment.getExecutionEnvironment
      import org.apache.flink.api.scala._
  
        env.fromCollection(List(
          (1L, 3d),
          (1L, 5d),
          (1L, 7d),
          (1L, 4d),
          (1L, 2d)
        ))
          .keyBy(_._1)
          .flatMap(new CountWindowAverage())
          .print()
      env.execute()
    }
  }
  
  class CountWindowAverage extends RichFlatMapFunction[(Long, Double), (Long, Double)] {
    //定义ValueState类型的变量
    private var sum: ValueState[(Long, Double)] = _
  
  
    override def open(parameters: Configuration): Unit = {
      //初始化获取历史状态的值
      sum = getRuntimeContext.getState(
        new ValueStateDescriptor[(Long, Double)]("average", classOf[(Long, Double)])
      )
    }
  
    override def flatMap(input: (Long, Double), out: Collector[(Long, Double)]): Unit = {
      // access the state value
      val tmpCurrentSum = sum.value
      // If it hasn't been used before, it will be null
      val currentSum = if (tmpCurrentSum != null) {
        tmpCurrentSum
      } else {
        (0L, 0d)
      }
      // update the count
      val newSum = (currentSum._1 + 1, currentSum._2 + input._2)
  
      // update the state
      sum.update(newSum)
  
      // if the count reaches 2, emit the average and clear the state
      if (newSum._1 >= 2) {
        out.collect((input._1, newSum._2 / newSum._1))
        //将状态清除
        //sum.clear()
      }
    }
  
  
  }
  
  ~~~


##### 1.3.2 ListState

* 作用

  * 用于保存每个key的历史数据数据成为一个列表

* 需求

  * 使用ListState求取数据平均值

* 代码开发

  ~~~scala
  package com.kaikeba.keystate
  
  import java.lang
  import java.util.Collections
  
  import org.apache.flink.api.common.functions.RichFlatMapFunction
  import org.apache.flink.api.common.state.{ListState, ListStateDescriptor}
  import org.apache.flink.configuration.Configuration
  import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
  import org.apache.flink.util.Collector
  
  /**
    * 使用ListState实现平均值求取
    * ListState<T> ：这个状态为每一个 key 保存集合的值
    *      get() 获取状态值
    *      add() / addAll() 更新状态值，将数据放到状态中
    *      clear() 清除状态
    */
  object ListStateOperate {
  
    def main(args: Array[String]): Unit = {
      val env = StreamExecutionEnvironment.getExecutionEnvironment
      import org.apache.flink.api.scala._
      env.fromCollection(List(
        (1L, 3d),
        (1L, 5d),
        (1L, 7d),
        (2L, 4d),
        (2L, 2d),
        (2L, 6d)
      )).keyBy(_._1)
        .flatMap(new CountWindowAverageWithList)
        .print()
      env.execute()
    }
  }
  
  
  
  class CountWindowAverageWithList extends RichFlatMapFunction[(Long,Double),(Long,Double)]{
    //定义我们历史所有的数据获取
    private var elementsByKey: ListState[(Long,Double)] = _
  
    override def open(parameters: Configuration): Unit = {
      //初始化获取历史状态的值，每个key对应的所有历史值，都存储在list集合里面了
      val listState = new ListStateDescriptor[(Long,Double)]("listState",classOf[(Long,Double)])
      elementsByKey = getRuntimeContext.getListState(listState)
  
    }
  
    override def flatMap(element: (Long, Double), out: Collector[(Long, Double)]): Unit = {
      //获取当前key的状态值
     val currentState: lang.Iterable[(Long, Double)] = elementsByKey.get()
  
      //如果初始状态为空，那么就进行初始化，构造一个空的集合出来，准备用于存储后续的数据
      if(currentState == null){
        elementsByKey.addAll(Collections.emptyList())
      }
      //添加元素
      elementsByKey.add(element)
      import scala.collection.JavaConverters._
      val allElements: Iterator[(Long, Double)] = elementsByKey.get().iterator().asScala
        
      val allElementList: List[(Long, Double)] = allElements.toList
      if(allElementList.size >= 3){
        var count = 0L
        var sum = 0d
        for(eachElement <- allElementList){
          count +=1
          sum += eachElement._2
        }
        out.collect((element._1,sum/count))
      }
    }
  }
  
  ~~~



##### 1.3.3 MapState

* 作用

  * 用于将每个key对应的数据都保存成一个map集合

* 需求

  * 使用MapState求取每个key对应的平均值

* 代码开发

  ~~~scala
  package com.kaikeba.keystate
  
  import java.util.UUID
  
  import org.apache.flink.api.common.functions.RichFlatMapFunction
  import org.apache.flink.api.common.state.{MapState, MapStateDescriptor}
  import org.apache.flink.configuration.Configuration
  import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
  import org.apache.flink.util.Collector
  
  /**
    * 使用MapState求取每个key对应的平均值
    */
  object MapStateOperate {
  
    def main(args: Array[String]): Unit = {
  
      val env = StreamExecutionEnvironment.getExecutionEnvironment
      import org.apache.flink.api.scala._
      env.fromCollection(List(
        (1L, 3d),
        (1L, 5d),
        (1L, 7d),
        (2L, 4d),
        (2L, 2d),
        (2L, 6d)
      )).keyBy(_._1)
        .flatMap(new CountWithAverageMapState)
        .print()
      env.execute()
    }
  }
  
  class CountWithAverageMapState extends RichFlatMapFunction[(Long,Double),(Long,Double)]{
    private var mapState:MapState[String,Double] = _
  
    //初始化获取mapState对象
    override def open(parameters: Configuration): Unit = {
      val mapStateOperate = new MapStateDescriptor[String,Double]("mapStateOperate",classOf[String],classOf[Double])
      mapState = getRuntimeContext.getMapState(mapStateOperate)
    }
    override def flatMap(input: (Long, Double), out: Collector[(Long, Double)]): Unit = {
      //将相同的key对应的数据放到一个map集合当中去，就是这种对应  1 -> List[Map,Map,Map]
      //每次都构建一个map集合
      mapState.put(UUID.randomUUID().toString,input._2)
      import scala.collection.JavaConverters._
  
      //获取map集合当中所有的value，我们每次将数据的value给放到map的value里面去
      val listState: List[Double] = mapState.values().iterator().asScala.toList
      if(listState.size >=3){
        var count = 0L
        var sum = 0d
        for(eachState <- listState){
          count +=1
          sum += eachState
        }
        println("average"+ sum/count)
        out.collect(input._1,sum/count)
      }
    }
  }
  ~~~



##### 1.3.4 ReducingState

* 作用

  * 用于数据的聚合

* 需求

  * 使用ReducingState求取每个key对应的平均值

* 代码开发

  ~~~scala
  package com.kaikeba.keystate
  
  import org.apache.flink.api.common.functions.{ReduceFunction, RichFlatMapFunction}
  import org.apache.flink.api.common.state.{ReducingState, ReducingStateDescriptor}
  import org.apache.flink.configuration.Configuration
  import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
  import org.apache.flink.util.Collector
  
  /**
    * ReducingState<T> ：这个状态为每一个 key 保存一个聚合之后的值
    * get() 获取状态值
    * add()  更新状态值，将数据放到状态中
    * clear() 清除状态
    */
  
  object ReduceingStateOperate {
    def main(args: Array[String]): Unit = {
      val env = StreamExecutionEnvironment.getExecutionEnvironment
      import org.apache.flink.api.scala._
      env.fromCollection(List(
        (1L, 3d),
        (1L, 5d),
        (1L, 7d),
        (2L, 4d),
        (2L, 2d),
        (2L, 6d)
      )).keyBy(_._1)
        .flatMap(new CountWithReduceingAverageStage)
        .print()
      env.execute()
    }
  }
  
  
  
  class CountWithReduceingAverageStage extends RichFlatMapFunction[(Long,Double),(Long,Double)]{
  
     //定义ReducingState
    private var reducingState:ReducingState[Double] = _
  
    //定义一个计数器
     var counter=0L
  
  
    override def open(parameters: Configuration): Unit = {
      
      val reduceSum = new ReducingStateDescriptor[Double]("reduceSum", new ReduceFunction[ Double] {
        override def reduce(value1: Double, value2: Double): Double = {
          value1+ value2
        }
      }, classOf[Double])
  
      //初始化获取mapState对象
      reducingState = getRuntimeContext.getReducingState[Double](reduceSum)
  
    }
    override def flatMap(input: (Long, Double), out: Collector[(Long, Double)]): Unit = {
      //计数器+1
      counter+=1
      //添加数据到reducingState
      reducingState.add(input._2)
  
      out.collect(input._1,reducingState.get()/counter)
    }
  }
  ~~~


##### 1.3.5 AggregatingState

* 作用

  * 将相同key的数据进行聚合

* 需求

  * 将相同key的数据聚合成为一个字符串

* 代码开发

  ~~~scala
  package com.kaikeba.keystate
  
  import org.apache.flink.api.common.functions.{AggregateFunction, RichFlatMapFunction}
  import org.apache.flink.api.common.state.{AggregatingState, AggregatingStateDescriptor}
  import org.apache.flink.configuration.Configuration
  import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
  import org.apache.flink.util.Collector
  
  /**
    * 将相同key的数据聚合成为一个字符串
    */
  object AggregrateStateOperate {
  
    def main(args: Array[String]): Unit = {
  
        val env = StreamExecutionEnvironment.getExecutionEnvironment
        import org.apache.flink.api.scala._
        env.fromCollection(List(
          (1L, 3d),
          (1L, 5d),
          (1L, 7d),
          (2L, 4d),
          (2L, 2d),
          (2L, 6d)
        )).keyBy(_._1)
          .flatMap(new AggregrageState)
          .print()
  
        env.execute()
      }
    }
  
    /**
      *   (1L, 3d),
          (1L, 5d),
          (1L, 7d),   把相同key的value拼接字符串：Contains+and+3+and+5+and+7
      */
    class AggregrageState extends RichFlatMapFunction[(Long,Double),(Long,String)]{
  
       //定义AggregatingState
      private var aggregateTotal:AggregatingState[Double, String] = _
  
      override def open(parameters: Configuration): Unit = {
        /**
          * name: String,
          * aggFunction: AggregateFunction[IN, ACC, OUT],
          * stateType: Class[ACC]
          */
        val aggregateStateDescriptor = new AggregatingStateDescriptor[Double, String, String]("aggregateState", new AggregateFunction[Double, String, String] {
           //创建一个初始值
          override def createAccumulator(): String = {
            "Contains"
          }
  
          //对数据进行累加
          override def add(value: Double, accumulator: String): String = {
            if ("Contains".equals(accumulator)) {
              accumulator + value
            }
  
            accumulator + "and" + value
          }
  
           //获取累加的结果
          override def getResult(accumulator: String): String = {
            accumulator
          }
  
          //数据合并的规则
          override def merge(a: String, b: String): String = {
            a + "and" + b
          }
        }, classOf[String])
        aggregateTotal = getRuntimeContext.getAggregatingState(aggregateStateDescriptor)
      }
  
      override def flatMap(input: (Long, Double), out: Collector[(Long, String)]): Unit = {
  
        aggregateTotal.add(input._2)
        out.collect(input._1,aggregateTotal.get())
      }
  
  
  }
  
  ~~~



#### 1.4  Operator State案例演示

* 需求
  * 实现每两条数据进行输出打印一次，不用区分数据的key
  * 这里使用ListState实现

~~~scala
package com.kaikeba.operatorstate

import org.apache.flink.streaming.api.functions.sink.SinkFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}

import scala.collection.mutable.ListBuffer

/**
  * 实现每两条数据进行输出打印一次，不用区分数据的key
  */
object OperatorListState {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.api.scala._
    val sourceStream: DataStream[(String, Int)] = env.fromCollection(List(
        ("spark", 3),
        ("hadoop", 5),
        ("hive", 7),
        ("flume", 9)
    ))

    sourceStream.addSink(new OperateTaskState).setParallelism(1)

    env.execute()
  }

}

class OperateTaskState extends SinkFunction[(String,Int)]{
  //定义一个list 用于我们每两条数据打印一下
  private var listBuffer:ListBuffer[(String,Int)] = new ListBuffer[(String, Int)]

  override def invoke(value: (String, Int), context: SinkFunction.Context[_]): Unit = {
    listBuffer.+=(value)

    if(listBuffer.size ==2){
       println(listBuffer)

      //清空state状态
      listBuffer.clear()
    }
  }

}



~~~





### :book: 2. Flink的状态管理之State Backend

* 默认情况下，state会保存在taskmanager的内存中，checkpoint会存储在JobManager的内存中。state 的存储和checkpoint的位置取决于State Backend的配置。
* ==Flink一共提供了3种StateBackend==
  * MemoryStateBackend	
    * 基于内存存储
  * FsStateBackend
    * 基于文件系统存储
  * RocksDBStateBackend
    * 基于数据库存储
* 可以通过  ==StreamExecutionEnvironment.setStateBackend(...)==来设置state存储的位置

#### 2.1 MemoryStateBackend

~~~
	将数据持久化状态存储到内存当中，state数据保存在java堆内存中，执行checkpoint的时候，会把state的快照数据保存到jobmanager的内存中。基于内存的state backend在生产环境下不建议使用。
~~~

![1587460628502](assets/MemoryStateBackend.png)

* 代码配置：

```scala
environment.setStateBackend(new MemoryStateBackend())
```



#### 2.2  FsStateBackend

~~~
	state数据保存在taskmanager的内存中，执行checkpoint的时候，会把state的快照数据保存到配置的文件系统中。可以使用hdfs等分布式文件系统.
	
	FsStateBackend 适合场景：状态数据特别的多，还有长时间的window算子等，它很安全，因为基于hdfs，所以数据有备份很安全。
~~~

![1587460786994](assets/FSStateBackend.png)

* 代码配置：

```scala
environment.setStateBackend(new FsStateBackend("hdfs://node01:8020/flink/checkDir"))
```

#### 2.3  RocksDBStateBackend   

~~~
RocksDB介绍：
	RocksDB使用一套日志结构的数据库引擎，它是Flink中内置的第三方状态管理器,为了更好的性能，这套引擎是用C++编写的。 Key和value是任意大小的字节流。RocksDB跟上面的都略有不同，它会在本地文件系统中维护状态，state会直接写入本地rocksdb中。同时它需要配置一个远端的filesystem uri（一般是HDFS），在做checkpoint的时候，会把本地的数据直接复制到fileSystem中。fail over的时候从fileSystem中恢复到本地RocksDB克服了state受内存限制的缺点，同时又能够持久化到远端文件系统中，比较适合在生产中使用.
~~~

![1587461111818](assets/RocksDBStateBackend.png)



* 代码配置：导入jar包然后配置代码

```xml
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-statebackend-rocksdb_2.11</artifactId>
    <version>1.9.2</version>
</dependency>
```

* 配置代码

```scala
environment.setStateBackend(new RocksDBStateBackend("hdfs://node01:8020/flink/checkDir",true))
```



#### 2.4  修改state-backend的两种方式

* 第一种：单任务调整
  * 修改当前任务代码

```scala
env.setStateBackend(
new FsStateBackend("hdfs://node01:8020/flink/checkDir"))
或者new MemoryStateBackend()
或者new RocksDBStateBackend(filebackend, true);【需要添加第三方依赖】
```

* 第二种：全局调整
  * 修改flink-conf.yaml

  ~~~yaml
  state.backend: filesystem
  state.checkpoints.dir: hdfs://node01:8020/flink/checkDir
  ~~~

  * 注意：state.backend的值可以是下面几种

  ~~~
  (1) jobmanager    表示使用 MemoryStateBackend
  (2) filesystem    表示使用 FsStateBackend
  (3) rocksdb       表示使用 RocksDBStateBackend
  ~~~



### :book: 3. Flink的checkPoint保存数据实现容错

#### 3.1 checkPoint的基本概念

~~~
为了保证state的容错性，Flink需要对state进行checkpoint。

	Checkpoint是Flink实现容错机制最核心的功能，它能够根据配置周期性地基于Stream中各个Operator/task的状态来生成快照，从而将这些状态数据定期持久化存储下来，当Flink程序一旦意外崩溃时，重新运行程序时可以有选择地从这些快照进行恢复，从而修正因为故障带来的程序数据异常。

~~~

#### 3.2  checkPoint的前提

* Flink的checkpoint机制可以与(stream和state)的持久化存储交互的前提
  * 1、持久化的source，它需要支持在一定时间内重放事件。这种sources的典型例子是持久化的消息队列（比如Apache Kafka，RabbitMQ等）或文件系统（比如HDFS，S3，GFS等）

  * 2、用于state的持久化存储，例如分布式文件系统（比如HDFS，S3，GFS等）

#### 3.3 Flink进行checkpoint步骤

- 暂停新数据的输入
- 等待流中on-the-fly的数据被处理干净，此时得到flink graph的一个snapshot
- 将所有Task中的State拷贝到State Backend中，如HDFS。此动作由各个Task Manager完成
- 各个Task Manager将Task State的位置上报给Job Manager，完成checkpoint
- 恢复数据的输入

如上所述，这里才需要“暂停输入  +  排干on-the-fly  数据”的操作，这样才能拿到同一时刻下所有subtask的state



#### 3.4  配置checkPoint

* 默认checkpoint功能是disabled的，想要使用的时候需要先启用

* checkpoint开启之后，默认的checkPointMode是Exactly-once

* checkpoint的checkPointMode有两种
  * Exactly-once:    数据处理且只被处理一次
  * At-least-once：数据至少被处理一次

Exactly-once对于大多数应用来说是最合适的。At-least-once可能用在某些延迟超低的应用程序（始终延迟为几毫秒）

```scala
//默认checkpoint功能是disabled的，想要使用的时候需要先启用
// 每隔1000 ms进行启动一个检查点【设置checkpoint的周期】
environment.enableCheckpointing(1000);
// 高级选项：
// 设置模式为exactly-once （这是默认值）
environment.getCheckpointConfig.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
// 确保检查点之间有至少500 ms的间隔【checkpoint最小间隔】
environment.getCheckpointConfig.setMinPauseBetweenCheckpoints(500);
// 检查点必须在一分钟内完成，或者被丢弃【checkpoint的超时时间】
environment.getCheckpointConfig.setCheckpointTimeout(60000);
// 同一时间只允许进行一个检查点
environment.getCheckpointConfig.setMaxConcurrentCheckpoints(1);
// 表示一旦Flink处理程序被cancel后，会保留Checkpoint数据，以便根据实际需要恢复到指定的Checkpoint【详细解释见备注】

/**
  * ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION:表示一旦Flink处理程序被cancel后，会保留Checkpoint数据，以便根据实际需要恢复到指定的Checkpoint
  * ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION: 表示一旦Flink处理程序被cancel后，会删除Checkpoint数据，只有job执行失败的时候才会保存checkpoint
  */
environment.getCheckpointConfig.enableExternalizedCheckpoints(ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);

```

 

#### 3.5  重启策略概述

* Flink支持不同的重启策略，以在故障发生时控制作业如何重启，集群在启动时会伴随一个默认的重启策略，在没有定义具体重启策略时会使用该默认策略。
*  如果在工作提交时指定了一个重启策略，该策略会覆盖集群的默认策略，默认的重启策略可以通过 Flink 的配置文件 flink-conf.yaml 指定。配置参数 restart-strategy 定义了哪个策略被使用。
* 常用的重启策略
  * （1）固定间隔 (Fixed delay)
  * （2）失败率 (Failure rate)
  * （3）无重启 (No restart)
* 如果没有启用 checkpointing，则使用无重启 (no restart) 策略。 
* 如果启用了 checkpointing，重启策略可以在==flink-conf.yaml==中配置，表示全局的配置。也可以在应用代码中动态指定，会覆盖全局配置
  * 但没有配置重启策略，则使用固定间隔 (fixed-delay) 策略， 尝试重启次数默认值是：Integer.MAX_VALUE，。

#### 3.6  重启策略配置实现

* 固定间隔 (Fixed delay)

```properties
第一种：全局配置 flink-conf.yaml
restart-strategy: fixed-delay
restart-strategy.fixed-delay.attempts: 3
restart-strategy.fixed-delay.delay: 10 s

第二种：应用代码设置
	//重启次数、重启时间间隔
environment.setRestartStrategy(RestartStrategies.fixedDelayRestart(5,10000))

```

* 失败率 (Failure rate)

```properties
第一种：全局配置 flink-conf.yaml
restart-strategy: failure-rate
restart-strategy.failure-rate.max-failures-per-interval: 3
restart-strategy.failure-rate.failure-rate-interval: 5 min
restart-strategy.failure-rate.delay: 10 s


第二种：应用代码设置
environment.setRestartStrategy(RestartStrategies.failureRateRestart(20, org.apache.flink.api.common.time.Time.seconds(10), org.apache.flink.api.common.time.Time.seconds(10)))

```

* 无重启 (No restart)

```properties
第一种：全局配置 flink-conf.yaml
restart-strategy: none

第二种：应用代码设置
environment.setRestartStrategy(RestartStrategies.noRestart())
```

### :book: 4.  从checkPoint恢复数据以及checkPoint保存多个历史版本

#### 4.1  保存多个历史版本

* 默认情况下，如果设置了Checkpoint选项，则Flink只保留最近成功生成的1个Checkpoint，而当Flink程序失败时，可以从最近的这个Checkpoint来进行恢复。
* 如果我们希望保留多个Checkpoint，并能够根据实际需要==选择其中一个进行恢复==，这样会更加灵活，比如，我们发现最近4个小时数据记录处理有问题，希望将整个状态还原到4小时之前

* Flink可以支持保留多个Checkpoint，需要在Flink的配置文件conf/flink-conf.yaml中，添加如下配置，指定最多需要保存Checkpoint的个数

```yaml
state.checkpoints.num-retained: 20
```

* 这样设置以后就查看对应的Checkpoint在HDFS上存储的文件目录

```yaml
hdfs dfs -ls hdfs://node01:8020/flink/checkpoints
```

* 如果希望回退到某个Checkpoint点，只需要指定对应的某个Checkpoint路径即可实现

#### 4.2 恢复历史某个版本数据

* 如果Flink程序异常失败，或者最近一段时间内数据处理错误，我们可以将程序从某一个Checkpoint点进行恢复

```scala
bin/flink run -s hdfs://node01:8020/flink/checkpoints/467e17d2cc343e6c56255d222bae3421/chk-56/_metadata flink-job.jar
```

* 程序正常运行后，还会按照Checkpoint配置进行运行，继续生成Checkpoint数据

 

### :book: 5. Flink的savePoint保存数据

#### 5.1 savePoint的介绍

* savePoint是检查点一种特殊实现，底层其实也是使用Checkpoints的机制。
* savePoint是用户以手工命令的方式触发checkpoint，并将结果持久化到指定的存储目录中

* 作用
  * 1、应用程序代码升级
    * 通过触发保存点并从该保存点处运行新版本，下游的应用程序并不会察觉到不同
  * 2、Flink版本更新
    * Flink 自身的更新也变得简单，因为可以针对正在运行的任务触发保存点，并从保存点处用新版本的 Flink 重启任务。
  * 3、维护和迁移
    * 使用保存点，可以轻松地“暂停和恢复”应用程序            

#### 5.2 savePoint的使用

* 1：在flink-conf.yaml中配置Savepoint存储位置

不是必须设置，但是设置后，后面创建指定Job的Savepoint时，可以不用在手动执行命令时指定Savepoint的位置

```yaml
state.savepoints.dir: hdfs://node01:8020/flink/savepoints
```

* 2：触发一个savepoint

  * （1）手动触发savepoint

    ~~~shell
    
    #【针对on standAlone模式】
    bin/flink savepoint jobId [targetDirectory] 
    
    #【针对on yarn模式需要指定-yid参数】
    bin/flink savepoint jobId [targetDirectory] [-yid yarnAppId]
    
    #jobId 				需要触发savepoint的jobId编号
    #targetDirectory     指定savepoint存储数据目录
    #-yid                指定yarnAppId 
    ~~~

  * （2）取消任务并手动触发savepoint

    ~~~shell
    ##【针对on standAlone模式】
    bin/flink cancel -s [targetDirectory] jobId 
    
    ##【针对on yarn模式需要指定-yid参数】
    bin/flink cancel -s [targetDirectory] jobId [-yid yarnAppId]
    ~~~



* 3：从指定的savepoint启动job

  ~~~shell
  bin/flink run -s savepointPath [runArgs]
  ~~~



* 4、清除savepoint数据

  ~~~shell
  bin/flink savepoint -d savepointPath
  ~~~




### :book: 6.  Flink流式处理集成kafka

* 对于实时处理当中，我们实际工作当中的数据源一般都是使用kafka，所以我们一起来看看如何通过Flink来集成kafka

* Flink提供了一个特有的kafka connector去读写kafka topic的数据。flink消费kafka数据，并不是完全通过跟踪kafka消费组的offset来实现去保证exactly-once的语义，而是flink内部去跟踪offset和做checkpoint去实现exactly-once的语义，而且对于kafka的partition，Flink会启动对应的并行度去处理kafka当中的每个分区的数据

* Flink整合kafka官网介绍
  * https://ci.apache.org/projects/flink/flink-docs-release-1.9/dev/connectors/kafka.html

#### 6.1 导入pom依赖

```xml
<!-- https://mvnrepository.com/artifact/org.apache.flink/flink-connector-kafka -->
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-connector-kafka_2.11</artifactId>
    <version>1.9.2</version>
</dependency>
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-statebackend-rocksdb_2.11</artifactId>
    <version>1.9.2</version>
</dependency>
<dependency>
    <groupId>org.apache.kafka</groupId>
    <artifactId>kafka-clients</artifactId>
    <version>1.1.0</version>
</dependency>
<dependency>
    <groupId>org.slf4j</groupId>
    <artifactId>slf4j-api</artifactId>
    <version>1.7.25</version>
</dependency>
<dependency>
    <groupId>org.slf4j</groupId>
    <artifactId>slf4j-log4j12</artifactId>
    <version>1.7.25</version>
</dependency>
```



#### 6.2 将kafka作为flink的source来使用

* 实际工作当中一般都是将kafka作为flink的source来使用

##### 6.2.1 创建kafka的topic

* 安装好kafka集群，并启动kafka集群，然后在node01执行以下命令创建kafka的topic为test

```shell
cd /kkb/install/kafka_2.11-1.1.0/
bin/kafka-topics.sh --create --partitions 3 --topic test --replication-factor 1 --zookeeper node01:2181,node02:2181,node03:2181
```

##### 6.2.2 代码实现：

```scala
package com.kaikeba.kafka

import java.util.Properties

import org.apache.flink.contrib.streaming.state.RocksDBStateBackend
import org.apache.flink.streaming.api.CheckpointingMode
import org.apache.flink.streaming.api.environment.CheckpointConfig
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer
import org.apache.flink.streaming.util.serialization.SimpleStringSchema

/**
  *  将kafka作为flink的source来使用
  */
object FlinkKafkaSource {

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    //**隐式转换
    import org.apache.flink.api.scala._
    //checkpoint**配置
    env.enableCheckpointing(100)
    env.getCheckpointConfig.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE)
    env.getCheckpointConfig.setMinPauseBetweenCheckpoints(500)
    env.getCheckpointConfig.setCheckpointTimeout(60000)
    env.getCheckpointConfig.setMaxConcurrentCheckpoints(1)
    env.getCheckpointConfig.enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION)
    //设置statebackend
    env.setStateBackend(new RocksDBStateBackend("hdfs://node01:8020/flink_kafka_sink/checkpoints",true));

    val topic = "test"
    val prop = new Properties()
    prop.setProperty("bootstrap.servers","node01:9092,node02:9092,node03:9092")
    prop.setProperty("group.id","con1")
    prop.setProperty("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
    prop.setProperty("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
    val kafkaConsumer = new FlinkKafkaConsumer[String]("test",new SimpleStringSchema,prop)
    kafkaConsumer.setCommitOffsetsOnCheckpoints(true)
    val kafkaSource: DataStream[String] = env.addSource(kafkaConsumer)
    kafkaSource.print()
    env.execute()


  }
}

```

##### 6.2.3 kafka生产数据

* node01执行以下命令，通过shell命令行来生产数据到kafka当中去

```shell
cd /kkb/install/kafka_2.11-1.1.0/
bin/kafka-console-producer.sh --broker-list node01:9092,node02:9092,node03:9092 --topic  test
```



#### 6.3 将kafka作为flink的sink来使用

* 我们也可以将kafka作为flink的sink来使用，就是将flink处理完成之后的数据写入到kafka当中去

##### 6.3.1 socket发送数据

* node01执行以下命令，从socket当中发送数据

```
 nc -lk 9999
```

##### 6.3.2 代码实现

```scala
package com.kaikeba.kafka

import java.util.Properties

import org.apache.flink.contrib.streaming.state.RocksDBStateBackend
import org.apache.flink.streaming.api.CheckpointingMode
import org.apache.flink.streaming.api.environment.CheckpointConfig
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer
import org.apache.flink.streaming.connectors.kafka.internals.KeyedSerializationSchemaWrapper
import org.apache.flink.streaming.util.serialization.SimpleStringSchema

/**
  * 将kafka作为flink的sink来使用
  */
object FlinkKafkaSink {

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    //隐式转换
    import org.apache.flink.api.scala._
      
    //checkpoint配置
    env.enableCheckpointing(5000);
    env.getCheckpointConfig.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
    env.getCheckpointConfig.setMinPauseBetweenCheckpoints(500);
    env.getCheckpointConfig.setCheckpointTimeout(60000);
    env.getCheckpointConfig.setMaxConcurrentCheckpoints(1);
    env.getCheckpointConfig.enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
    //设置statebackend
    env.setStateBackend(new RocksDBStateBackend("hdfs://node01:8020/flink_kafka_sink/checkpoints",true));
    val socketStream = env.socketTextStream("node01",9999)
    val topic = "test"
    val prop = new Properties()
    prop.setProperty("bootstrap.servers","node01:9092,node02:9092,node03:9092")
    prop.setProperty("group.id","kafka_group1")
    //第一种解决方案，设置FlinkKafkaProducer里面的事务超时时间
    //设置事务超时时间
    prop.setProperty("transaction.timeout.ms",60000*15+"");
      
    //第二种解决方案，设置kafka的最大事务超时时间
    //FlinkKafkaProducer011<String> myProducer = new FlinkKafkaProducer<>(brokerList, topic, new SimpleStringSchema());
    
      //使用支持仅一次语义的形式
    /**
      * defaultTopic: String,
      * serializationSchema: KafkaSerializationSchema[IN],
      * producerConfig: Properties,
      * semantic: FlinkKafkaProducer.Semantic
      */
    val kafkaSink = new FlinkKafkaProducer[String](topic,new KeyedSerializationSchemaWrapper[String](new SimpleStringSchema()), prop,FlinkKafkaProducer.Semantic.EXACTLY_ONCE)
    socketStream.addSink(kafkaSink)

    env.execute("StreamingFromCollectionScala")

  }
}

```

##### 6.3.3 启动kafka消费者

* node01执行以下命令启动kafka消费者，消费数据

```shell
cd /kkb/install/kafka_2.11-1.1.0
bin/kafka-console-consumer.sh --bootstrap-server node01:9092,node02:9092,node03:9092 --topic test
```

### :book: 7. Flink当中的window窗口

* 对于流式处理，如果我们需要求取总和，平均值，或者最大值，最小值等，是做不到的，因为数据一直在源源不断的产生，即数据是没有边界的，所以没法求最大值，最小值，平均值等，所以为了一些数值统计的功能，我们必须指定时间段，对某一段时间的数据求取一些数据值是可以做到的。或者对某一些数据求取数据值也是可以做到的
* 所以，流上的聚合需要由 window 来划定范围，比如 “计算过去的5分钟” ，或者 “最后100个元素的和” 。
* window是一种可以把无限数据切割为有限数据块的手段
  * 窗口可以是 时间驱动的 【Time Window】（比如：每30秒）
  * 或者 数据驱动的【Count Window】 （比如：每100个元素）

![1584599129746](assets/1584599129746.png)

* 窗口类型汇总：


![1587473202406](assets/window.png)



#### 7.1 窗口的基本类型介绍

* 窗口通常被区分为不同的类型:
  * tumbling windows：滚动窗口 【没有重叠】 

    * 滚动窗口下窗口之间之间不重叠，且窗口长度是固定的

    ![](assets/tumbling windows.png)

  * sliding windows：滑动窗口 【有重叠】

    * 滑动窗口以一个步长（Slide）不断向前滑动，窗口的长度固定

    ![1587473504462](assets/sliding windows.png)

  * session windows：会话窗口 ，一般没人用

    * 会话窗口根据Session gap切分不同的窗口，当一个窗口在大于Session gap的时间内没有接收到新数据时，窗口将关闭

    ![1587473534498](assets/session windows.png)



#### 7.2  Flink的窗口介绍

##### 7.2.1 Time Window窗口的应用

* time window又分为滚动窗口和滑动窗口，这两种窗口调用方法都是一样的，都是调用timeWindow这个方法，如果传入==一个参数就是滚动窗口==，如果传入==两个参数就是滑动窗口==

​     ![](assets/1584599265529.png)



* 需求：每隔5s时间，统计最近10s出现的数据

* 代码实现：

```scala
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.streaming.api.windowing.time.Time

object TestTimeWindow {

  def main(args: Array[String]): Unit = {
    val environment: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment

    import org.apache.flink.api.scala._
    val socketSource: DataStream[String] = environment.socketTextStream("node01",9999)

    socketSource
      .flatMap(x => x.split(" "))
      .map(x =>(x,1))
      .keyBy(0)
      .timeWindow(Time.seconds(10),Time.seconds(5))
      .sum(1).print()
    environment.execute()

  }

}
```



##### 7.2.2 Count Windos窗口的应用

* 与timeWindow类型，CountWinodw也可以分为滚动窗口和滑动窗口，这两个窗口调用方法一样，都是调用countWindow，如果传入一个参数就是滚动窗口，如果传入两个参数就是滑动窗口

  ​     ![1584599273870](assets/1584599273870.png)



* 需求：使用count Window 统计最近5条数的最大值

```scala
import org.apache.flink.api.common.functions.AggregateFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}

/**
  * 使用countWindow统计最近5条数据的最大值
  */
object TestCountWindow {

  def main(args: Array[String]): Unit = {
    val environment: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.api.scala._
    val socketSource: DataStream[String] = environment.socketTextStream("node01",9999)

    /**
      * 发送数据
      * spark 1
      * spark 2
      * spark 3
      * spark 4
      * spark 5
      * hello 100
      * hello 90
      * hello 80
      * hello 70
      * hello 60
      * hello 10
      */
    socketSource.map(x => (x.split(" ")(0),x.split(" ")(1).toInt))
    .keyBy(0).countWindow(5)
        .aggregate(new AggregateFunction[(String,Int),Int,Double]{
          var initAccumulator :Int = 0
          override def createAccumulator(): Int = {
            initAccumulator
          }

          override def add(value: (String, Int), accumulator: Int): Int = {
            if(accumulator >= value._2){
              accumulator
            }else{
              value._2
            }
          }

          override def getResult(accumulator: Int): Double = {
            accumulator

          }

          override def merge(a: Int, b: Int): Int = {
            if(a>=b){
              a
            }else{
              b
            }
          }
        }).print()

    environment.execute()
  }
}
```



##### 7.2.3 自定义window的应用

* 如果time window 和 countWindow 还不够用的话，我们还可以使用自定义window来实现数据的统计等功能。

   ![1584599280754](assets/1584599280754.png)

 



#### 7.3 window窗口数据的集合统计

* 前面我们可以通过aggregrate实现数据的聚合，对于求最大值，最小值，平均值等操作，我们也可以通过process方法来实现

* 对于某一个window内的数值统计，我们可以增量的聚合统计或者全量的聚合统计

##### 7.3.1 增量聚合统计

* 窗口当中每加入一条数据，就进行一次统计
* 常用的聚合算子
  *  reduce(reduceFunction)
  *  aggregate(aggregateFunction)
  *  sum()、min()、max()

  ![flink-window函数增量统计](assets/flink-window函数增量统计.png)

* 需求

  * 通过接收socket当中输入的数据，统计每5秒钟数据的累计的值
* 代码实现

```scala
package com.kaikeba.window

import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.streaming.api.windowing.time.Time

object FlinkTimeCount {

  def main(args: Array[String]): Unit = {

      val environment: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
      import org.apache.flink.api.scala._

      val socketStream: DataStream[String] = environment.socketTextStream("node01",9999)

      socketStream.map(x => (1, x.toInt))
                  .keyBy(0)
                  .timeWindow(Time.seconds(5))
                  .reduce((c1,c2)=>(c1._1,c1._2+c2._2))
                  .print()

      environment.execute("FlinkTimeCount")
    }

}


```



##### 7.3.2 全量聚合统计

* 等到窗口截止，或者窗口内的数据全部到齐，然后再进行统计，可以用于求窗口内的数据的最大值，或者最小值，平均值等

* 等属于窗口的数据到齐，才开始进行聚合计算【可以实现对窗口内的数据进行排序等需求】
  * apply(windowFunction)
  * process(processWindowFunction)
  * processWindowFunction比windowFunction提供了更多的上下文信息。

* 需求
  * 通过全量聚合统计，求取每3条数据的平均值
* 代码实现

```scala
package com.kaikeba.window

import org.apache.flink.api.java.tuple.Tuple
import org.apache.flink.streaming.api.scala.function.ProcessWindowFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow
import org.apache.flink.util.Collector

/**
  * 求取每3条数据的平均值
  */
object FlinkCountWindowAvg {
  /**
    * 输入数据
    * 1
    * 2
    * 3
    * 4
    * 5
    * 6
    * @param args
    */
  def main(args: Array[String]): Unit = {
    val environment: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment

    import org.apache.flink.api.scala._

    val socketStream: DataStream[String] = environment.socketTextStream("node01",9999)

    //统计一个窗口内的数据的平均值
    socketStream.map(x => (1, x.toInt))
                .keyBy(0)
                .countWindow(3)
                //通过process方法来统计窗口的平均值
                .process(new MyProcessWindowFunctionclass)
                .print()

    //必须调用execute方法，否则程序不会执行
    environment.execute("count avg")
  }
}

/**ProcessWindowFunction 需要跟四个参数
  * 输入参数类型，输出参数类型，聚合的key的类型，window的下界
  *
  */
class MyProcessWindowFunctionclass extends ProcessWindowFunction[(Int , Int) , Double , Tuple , GlobalWindow]{

  override def process(key: Tuple, context: Context, elements: Iterable[(Int, Int)], out: Collector[Double]): Unit = {
    var totalNum = 0;
    var countNum = 0;
    for(data <-  elements){
      totalNum +=1
      countNum += data._2
    }
    out.collect(countNum/totalNum)
  }
}
```





## :five: 五 、招聘要求介绍





## :six: 六 、总结

1. 整理Xmind笔记





## :seven: 七 、作业

1. 把所有的代码都敲一遍





## :eight: 八 、互动

