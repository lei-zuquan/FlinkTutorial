package com.kkb.flink.demo1

package com.kaikeba.demo1

import org.apache.flink.api.common.restartstrategy.RestartStrategies
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
/**
  * 使用滑动窗口
  * 每隔1秒钟统计最近2秒钟的每个单词出现的次数
  */
object FlinkStream {

  def main(args: Array[String]): Unit = {
    //构建流处理的环境  可以在本地使用localhost:8081来查看web管理界面
    val environment: StreamExecutionEnvironment = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI()
    environment.setRestartStrategy(RestartStrategies.failureRateRestart(20, org.apache.flink.api.common.time.Time.seconds(10), org.apache.flink.api.common.time.Time.seconds(10)))
    //默认checkpoint功能是disabled的，想要使用的时候需要先启用//默认checkpoint功能是disabled的，想要使用的时候需要先启用
    //从socket获取数据
    val sourceStream: DataStream[String] = environment.socketTextStream("node01",9999)
    //导入隐式转换的包
    import org.apache.flink.api.scala._
    //对数据进行处理
    val result: DataStream[(String, Int)] = sourceStream
      .flatMap(x => x.split(" ")) //按照空格切分
      .map(x => (x, 1))  //每个单词计为1
      .keyBy(0)         //按照下标为0的单词进行分组
      .sum(1)          //按照下标为1累加相同单词出现的1
    //对数据进行打印
    result.print()
    //开启任务
    environment.execute("FlinkStream")
  }

}
